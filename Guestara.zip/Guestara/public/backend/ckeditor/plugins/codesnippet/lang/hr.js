/**
 * @license Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'codesnippet', 'hr', {
	button: 'Ubaci isječak kôda',
	codeContents: 'Sadržaj kôda',
	emptySnippetError: 'Isječak kôda ne može biti prazan.',
	language: 'Jezik',
	title: 'Isječak kôda',
	pathName: 'isječak kôda'
} );
